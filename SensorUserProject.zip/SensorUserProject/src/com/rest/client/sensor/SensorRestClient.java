package com.rest.client.sensor;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import user.sensor.data.pojo.Sensor;
import user.sensor.data.pojo.User;

public class SensorRestClient {

	/**
	 * @param args
	 */
	/**
	 * @param args
	 */
	/**
	 * @param args
	 */
	public static void main(String[] args) {
	
		 RestTemplate restTemplate = new RestTemplate();
		 
	       /* System.out.println("Executing and Testing method one using RestTemplate");
	        String strIplTeamName = restTemplate.getForObject("http://localhost:9989/User_Sensor_Data_Application/sensor/getUser/42342", String.class);
	        System.out.println(strIplTeamName);
	 */
		 	System.out.println("\n\nExecuting and Testing method two using RestTemplate");
	        User userObj = restTemplate.getForObject("http://localhost:9989/User_Sensor_Data_Application/sensor/getUser/182846628",User.class);
	        if(userObj!=null){
	        	System.out.println(userObj.getId() + "\t" + userObj.getUserName()+ "\t" );	
	        }else{
	        	System.out.println("No data found for the user..Please Register");
	        }
	        
	        System.out.println("\n\nExecuting and Testing method two using RestTemplate");
	        Sensor sens = restTemplate.getForObject("http://localhost:9989/User_Sensor_Data_Application/sensor/getSensor/754854777",Sensor.class);
	        if(sens!=null){
	        	System.out.println(sens.getSensId() + "\t" + sens.getSensName()+" ,"+sens.getSensName() );	
	        }else{
	        	System.out.println("No data found for the user..Please Register");
	        }
	        
	        // Below code keeps posing sensor and user data to the system
	        
	       int count = 0;
	        while(count < 1000){
	        	
	        	ResponseEntity<String> responseForInertSensor = restTemplate.getForEntity("http://localhost:9989/User_Sensor_Data_Application/sensor/user/save/sensor", String.class);
		        
		        if(responseForInertSensor.getStatusCode().value()==200){
		        	System.out.println("Got the resopose success");
		        	System.out.println(responseForInertSensor.getBody());
		        }else{
		        	System.out.println("not received success response");
		        }
		        
		        
		        ResponseEntity<String> responseForInertUser = restTemplate.getForEntity("http://localhost:9989/User_Sensor_Data_Application/sensor/user/save", String.class);
		        
		        if(responseForInertUser.getStatusCode().value()==200){
		        	System.out.println(responseForInertUser.getBody());
		        }else{
		        	System.out.println("not received success response");
			    }
		        
		        count++;
		        
		        Thread.sleep(500);
	        }
	        
	}
}
