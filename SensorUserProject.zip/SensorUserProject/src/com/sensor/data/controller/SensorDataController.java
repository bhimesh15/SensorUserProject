package com.sensor.data.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.SystemEnvironmentPropertySource;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.view.RedirectView;

import com.sensor.data.service.SensorDataService;
import com.sensor.data.service.UserDataService;

import user.sensor.data.pojo.Sensor;
import user.sensor.data.pojo.User;

@Controller
@RequestMapping("/sensor")
public class SensorDataController {
    // http://localhost:8081/SpringMVC-REST/cricket/getiplteam/MI

	@Autowired
	SensorDataService sensorDataService;
	
	@Autowired
	UserDataService userDataService;
    
    /**
     * @param model
     * @return Which returns list of data
     */
    @RequestMapping(value = "/user/data", method = RequestMethod.GET)  
	public String getUserList(ModelMap model) {
    	List<User> list = userDataService.listOfUsers();
    	if(!(list==null)){
    		System.out.println("list:"+list.size());    		
    	}
        model.addAttribute("userListData", list);  
        return "userList";
        
    }
    
    /**
     * @param userObj
     * @param model
     * @return Which is deleting selecting record based on the value which we are sending through UI
     */
    @RequestMapping(value = "/user/data/delete", method = RequestMethod.GET)  
   	public View userDelete(@ModelAttribute User userObj, ModelMap model) {
     	userDataService.deletePerson(userObj);
     	http://localhost:9989/User_Sensor_Data_Application/sensor/user/data
         //return new RedirectView("/mongo_db_ex/person");  
     	return new RedirectView("/User_Sensor_Data_Application/sensor/user/data");
       }
     
    
    /**
     * @param userObj
     * @param model
     * @return
     * 
     * Which return the data posted to the system
     */
    @RequestMapping(value = "/user/save", method = RequestMethod.GET)  
  	public String createPersonBYGET(@ModelAttribute User userObj, ModelMap model) {
      	userDataService.addUser(userObj);
      	model.addAttribute("msg", "User is been added to the System");
      	model.addAttribute("msgID", userObj.getId());
      	//return new RedirectView("/sensor/user/data");
      	/*List<User> list = userDataService.listOfUsers();
    	if(!(list==null)){
    		System.out.println("list:"+list.size());    		
    	}
        model.addAttribute("userListData", list); */
      	//return new RedirectView("/User_Sensor_Data_Application/sensor/user/data"); 
      	return "userList";
      }
 
    // POSTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT
    //   sensor/user/insert
    
    /**
     * @param userObj
     * @param model
     * @return Which store the data to the system.
     */
    @RequestMapping(value="/", method = RequestMethod.POST)  
  	public String addUserBYPOST(@ModelAttribute User userObj, ModelMap model) {
      	userDataService.addUser(userObj);
      	model.addAttribute("msg", "User is been added to the System");
      	model.addAttribute("msgID", userObj.getId());
      	return "userList";
      //	return new RedirectView("/User_Sensor_Data_Application/sensor/user/data");
      }
    
    /**
     * @param id
     * @return Which method gets called from client and give the response as user object
     */
    @RequestMapping(value="/getUser/{id}", method=RequestMethod.GET,produces=MediaType.ALL_VALUE)
    @ResponseBody
    public User getGetUserDetails(@PathVariable int id) {
 
    	System.out.println("fdsfsdjfljfsdjfsldfjsdf");
    	User u = new User();
    	u.setId(id);
    	User returnUser = userDataService.findUser(u);
    	if(returnUser!=null){
    		return returnUser;	
    	}
		return null;
    }
    


    //System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
    //System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
    //System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
    

    /**
     * @param model
     * @return
     * Which returns list of data
     */
    @RequestMapping(value = "/user/data/sensor", method = RequestMethod.GET)  
	public String getSensorUserList(ModelMap model) {
    	List<Sensor> list = sensorDataService.listOfSensor();
    	if(!(list==null)){
    		System.out.println("list:"+list.size());    		
    	}
        model.addAttribute("sensorListData", list);  
        return "sensorList";
        
    }
    
    /**
     * @param userObj
     * @param model
     * @return
     * Which is deleting selecting record based on the value which we are sending through UI+
     */
    @RequestMapping(value = "/user/data/delete", method = RequestMethod.GET)  
   	public View sensorDelete(@ModelAttribute Sensor userObj, ModelMap model) {
    	sensorDataService.deletePerson(userObj);
     	http://localhost:9989/User_Sensor_Data_Application/sensor/user/data
         //return new RedirectView("/mongo_db_ex/person");  
     	return new RedirectView("/User_Sensor_Data_Application/sensor/user/data/sensor");
       }
     
    
    /**
     * @param userObj
     * @param model
     * @return
     * 
     */
    @RequestMapping(value = "/user/save/sensor", method = RequestMethod.GET)  
  	public String createSensorBYGET(@ModelAttribute Sensor userObj, ModelMap model) {
    	sensorDataService.addUser(userObj);
      	model.addAttribute("msg", "User is been added to the System");
      	model.addAttribute("msgID", userObj.getSensId());
      	return "sensorList";
      }
    
    /**
     * @param userObj
     * @param model
     * @return
     */
    @RequestMapping(value="/", method = RequestMethod.GET)  
  	public String addSensorBYPOST(@ModelAttribute Sensor userObj, ModelMap model) {
    	System.out.println("##############################");
    	sensorDataService.addUser(userObj);
      	model.addAttribute("msg", "User is been added to the System");
      	model.addAttribute("msgID", userObj.getSensId());
      	model.addAttribute("sensName", userObj.getSensName());
      	model.addAttribute("sensType", userObj.getSensType());
      	return "sensorList";
      }
    
    /**
     * @param id
     * @return 
     * Which method gets called from client and give the response as user Sensor
     */
    @RequestMapping(value="/getSensor/{id}", method=RequestMethod.GET,produces=MediaType.ALL_VALUE)
    @ResponseBody
    public Sensor getGetSensorDetails(@PathVariable int id) {
 
    	Sensor u = new Sensor();
    	u.setSensId(id);
    	Sensor returnUser = sensorDataService.findUser(u);
    	if(returnUser!=null){
    		return returnUser;	
    	}
		return null;
    }
    
    
    
}
