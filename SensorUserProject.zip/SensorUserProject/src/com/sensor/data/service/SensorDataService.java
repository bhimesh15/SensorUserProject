package com.sensor.data.service;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import user.sensor.data.pojo.Sensor;
import user.sensor.data.pojo.User;

@Repository
public class SensorDataService {
	

	static Long ranDomNumber = 200564654227L;
	static Random rand = new Random(ranDomNumber);
	
	public static final String COLLECTION_NAME = "sensor";
	
	@Autowired
	private MongoTemplate mongoTemplate;

	public List<Sensor> listOfSensor() {
		// TODO Auto-generated method stub
		

		// TODO Auto-generated method stub
		Sensor userObj = new Sensor();
		if ((mongoTemplate.collectionExists(User.class))) {
			
			++ranDomNumber;
		     int ranDomNumberGen = rand.nextInt();
		     userObj.setSensId(ranDomNumberGen);
		     userObj.setSensName("bhimesh");
		     userObj.setSensType("SensorType");
		     mongoTemplate.insert(userObj, COLLECTION_NAME);
		}
		return mongoTemplate.findAll(Sensor.class, COLLECTION_NAME);
	}

	public List<User> listSensorData() {
		return mongoTemplate.findAll(Sensor.class, COLLECTION_NAME);
	}

	public Sensor findUser(Sensor u) {
		return mongoTemplate.findById(u.getSensId(), Sensor.class);
	}

	public void addUser(Sensor userObj) {
		System.out.println("add user****************");
		if (!(mongoTemplate.collectionExists(User.class))) {
			++ranDomNumber;
			 int ranDomNumberGen = rand.nextInt();
		     userObj.setSensId(ranDomNumberGen);
		     userObj.setSensName("bhimesh");
		     userObj.setSensType("SensorType");
		     mongoTemplate.insert(userObj, COLLECTION_NAME);
		}else{
			++ranDomNumber;
		    int ranDomNumberGen = rand.nextInt();
			mongoTemplate.createCollection(Sensor.class);
			 int ranDomNumberGen = rand.nextInt();
		     userObj.setSensId(ranDomNumberGen);
		     userObj.setSensName("bhimesh");
		     userObj.setSensType("SensorType");
			mongoTemplate.insert(userObj, COLLECTION_NAME);
		}
	}

	public void deletePerson(Sensor userObj) {

		// TODO Auto-generated method stub
		mongoTemplate.remove(userObj.getSensId(), COLLECTION_NAME);
		
	}
}
