package com.sensor.data.service;

import java.util.List;
import java.util.Random;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;
import user.sensor.data.pojo.Sensor;
import user.sensor.data.pojo.User;

@Repository
public class UserDataService {
	
	
	static Long ranDomNumber = 200564654227L;
	static Random rand = new Random(ranDomNumber);
	
	public static final String COLLECTION_NAME = "user";
	
	@Autowired
	private MongoTemplate mongoTemplate;

	public List<User> listOfUsers() {
		// TODO Auto-generated method stub
		User userObj = new User();
		if ((mongoTemplate.collectionExists(User.class))) {
			
			++ranDomNumber;
		     int ranDomNumberGen = rand.nextInt();
		     userObj.setId(ranDomNumberGen);
		     userObj.setUserName("bhimesh");
		     mongoTemplate.insert(userObj, COLLECTION_NAME);
		}
		return mongoTemplate.findAll(User.class, COLLECTION_NAME);
	}

	public void addUser(User userObj) {
		System.out.println("add user****************");
		if (!(mongoTemplate.collectionExists(User.class))) {
			++ranDomNumber;
		     int ranDomNumberGen = rand.nextInt();
		     userObj.setId(ranDomNumberGen);
		     userObj.setUserName("bhimesh"+ranDomNumber);
		     mongoTemplate.insert(userObj, COLLECTION_NAME);
		}else{
			++ranDomNumber;
		    int ranDomNumberGen = rand.nextInt();
			mongoTemplate.createCollection(User.class);
			userObj.setId(ranDomNumberGen);
			mongoTemplate.insert(userObj, COLLECTION_NAME);
		}
	}

	public void deletePerson(User userObj) {
		// TODO Auto-generated method stub
		System.out.println("userObj.getUserId()"+userObj.getId());
		mongoTemplate.remove(userObj, COLLECTION_NAME);
		
	}

	public User findUser(User ur) {
		// TODO Auto-generated method stub
		
		return mongoTemplate.findById(ur.getId(), User.class);
	}

}
