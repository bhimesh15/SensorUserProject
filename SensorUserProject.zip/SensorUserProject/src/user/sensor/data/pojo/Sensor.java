package user.sensor.data.pojo;

import javax.xml.bind.annotation.XmlElement;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Sensor {

	@XmlElement(name = "id")
	private int id;
	
	@XmlElement(name = "sensName")
	private String sensName;
	
	@XmlElement(name = "sensType")
	private String sensType;
	public int getSensId() {
		return id;
	}
	public void setSensId(int sensId) {
		this.id = sensId;
	}
	public String getSensName() {
		return sensName;
	}
	public void setSensName(String sensName) {
		this.sensName = sensName;
	}
	public String getSensType() {
		return sensType;
	}
	public void setSensType(String sensType) {
		this.sensType = sensType;
	}
}
